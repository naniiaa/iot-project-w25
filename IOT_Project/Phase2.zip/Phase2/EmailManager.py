import smtplib
import imaplib
import email
import re # Python RegEX Library to search for the word.

Sender_Email = ""
Key = ""

def email_notification(message):


def email_word_catch():


    if ():
        return True;
    else:
        return False;